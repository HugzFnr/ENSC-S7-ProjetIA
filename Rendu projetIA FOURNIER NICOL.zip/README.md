# ENSC-S7-ProjetIA
