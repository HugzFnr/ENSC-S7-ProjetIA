﻿namespace Resolution_taquin
{
    partial class FormTaquin5X5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblArbreExploration = new System.Windows.Forms.Label();
            this.lblCoupGagner = new System.Windows.Forms.Label();
            this.trArbreExploration = new System.Windows.Forms.TreeView();
            this.lbCoupGagner = new System.Windows.Forms.ListBox();
            this.gbResultats = new System.Windows.Forms.GroupBox();
            this.lblNbNoeudsFermesRes = new System.Windows.Forms.Label();
            this.lblNbNoeudsOuvertsRes = new System.Windows.Forms.Label();
            this.lblTempsCalculRes = new System.Windows.Forms.Label();
            this.lblNoeudsFermes = new System.Windows.Forms.Label();
            this.lblNoeudsOuverts = new System.Windows.Forms.Label();
            this.lblTempsCalcul = new System.Windows.Forms.Label();
            this.gbTaquin = new System.Windows.Forms.GroupBox();
            this.tbTaquin24 = new System.Windows.Forms.TextBox();
            this.tbTaquin23 = new System.Windows.Forms.TextBox();
            this.tbTaquin22 = new System.Windows.Forms.TextBox();
            this.tbTaquin21 = new System.Windows.Forms.TextBox();
            this.tbTaquin20 = new System.Windows.Forms.TextBox();
            this.tbTaquin19 = new System.Windows.Forms.TextBox();
            this.tbTaquin18 = new System.Windows.Forms.TextBox();
            this.tbTaquin17 = new System.Windows.Forms.TextBox();
            this.tbTaquin16 = new System.Windows.Forms.TextBox();
            this.tbTaquin15 = new System.Windows.Forms.TextBox();
            this.tbTaquin14 = new System.Windows.Forms.TextBox();
            this.tbTaquin13 = new System.Windows.Forms.TextBox();
            this.tbTaquin12 = new System.Windows.Forms.TextBox();
            this.tbTaquin11 = new System.Windows.Forms.TextBox();
            this.tbTaquin10 = new System.Windows.Forms.TextBox();
            this.tbTaquin9 = new System.Windows.Forms.TextBox();
            this.tbTaquin7 = new System.Windows.Forms.TextBox();
            this.tbTaquin8 = new System.Windows.Forms.TextBox();
            this.tbTaquin6 = new System.Windows.Forms.TextBox();
            this.tbTaquin5 = new System.Windows.Forms.TextBox();
            this.tbTaquin4 = new System.Windows.Forms.TextBox();
            this.tbTaquin3 = new System.Windows.Forms.TextBox();
            this.tbTaquin2 = new System.Windows.Forms.TextBox();
            this.tbTaquin1 = new System.Windows.Forms.TextBox();
            this.tbTaquin0 = new System.Windows.Forms.TextBox();
            this.lblInitTaquin = new System.Windows.Forms.Label();
            this.lblTitre = new System.Windows.Forms.Label();
            this.gbAction = new System.Windows.Forms.GroupBox();
            this.btnChoixTaquin3 = new System.Windows.Forms.Button();
            this.btnChoixTaquin2 = new System.Windows.Forms.Button();
            this.btnChoixTaquin1 = new System.Windows.Forms.Button();
            this.lblChoixTaquin = new System.Windows.Forms.Label();
            this.btnResoudre = new System.Windows.Forms.Button();
            this.gbResultats.SuspendLayout();
            this.gbTaquin.SuspendLayout();
            this.gbAction.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblArbreExploration
            // 
            this.lblArbreExploration.AutoSize = true;
            this.lblArbreExploration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblArbreExploration.Location = new System.Drawing.Point(692, 78);
            this.lblArbreExploration.Name = "lblArbreExploration";
            this.lblArbreExploration.Size = new System.Drawing.Size(98, 40);
            this.lblArbreExploration.TabIndex = 15;
            this.lblArbreExploration.Text = "Arbre\r\nd\'exploration";
            this.lblArbreExploration.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCoupGagner
            // 
            this.lblCoupGagner.AutoSize = true;
            this.lblCoupGagner.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblCoupGagner.Location = new System.Drawing.Point(411, 78);
            this.lblCoupGagner.Name = "lblCoupGagner";
            this.lblCoupGagner.Size = new System.Drawing.Size(91, 40);
            this.lblCoupGagner.TabIndex = 14;
            this.lblCoupGagner.Text = "Coups pour\r\ngagner";
            this.lblCoupGagner.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // trArbreExploration
            // 
            this.trArbreExploration.Location = new System.Drawing.Point(608, 136);
            this.trArbreExploration.Name = "trArbreExploration";
            this.trArbreExploration.Size = new System.Drawing.Size(263, 264);
            this.trArbreExploration.TabIndex = 13;
            // 
            // lbCoupGagner
            // 
            this.lbCoupGagner.FormattingEnabled = true;
            this.lbCoupGagner.Location = new System.Drawing.Point(316, 136);
            this.lbCoupGagner.Name = "lbCoupGagner";
            this.lbCoupGagner.Size = new System.Drawing.Size(259, 264);
            this.lbCoupGagner.TabIndex = 12;
            // 
            // gbResultats
            // 
            this.gbResultats.Controls.Add(this.lblNbNoeudsFermesRes);
            this.gbResultats.Controls.Add(this.lblNbNoeudsOuvertsRes);
            this.gbResultats.Controls.Add(this.lblTempsCalculRes);
            this.gbResultats.Controls.Add(this.lblNoeudsFermes);
            this.gbResultats.Controls.Add(this.lblNoeudsOuverts);
            this.gbResultats.Controls.Add(this.lblTempsCalcul);
            this.gbResultats.Location = new System.Drawing.Point(12, 408);
            this.gbResultats.Name = "gbResultats";
            this.gbResultats.Size = new System.Drawing.Size(257, 92);
            this.gbResultats.TabIndex = 11;
            this.gbResultats.TabStop = false;
            this.gbResultats.Text = "Résultats";
            // 
            // lblNbNoeudsFermesRes
            // 
            this.lblNbNoeudsFermesRes.AutoSize = true;
            this.lblNbNoeudsFermesRes.Location = new System.Drawing.Point(159, 71);
            this.lblNbNoeudsFermesRes.Name = "lblNbNoeudsFermesRes";
            this.lblNbNoeudsFermesRes.Size = new System.Drawing.Size(0, 13);
            this.lblNbNoeudsFermesRes.TabIndex = 5;
            // 
            // lblNbNoeudsOuvertsRes
            // 
            this.lblNbNoeudsOuvertsRes.AutoSize = true;
            this.lblNbNoeudsOuvertsRes.Location = new System.Drawing.Point(164, 47);
            this.lblNbNoeudsOuvertsRes.Name = "lblNbNoeudsOuvertsRes";
            this.lblNbNoeudsOuvertsRes.Size = new System.Drawing.Size(0, 13);
            this.lblNbNoeudsOuvertsRes.TabIndex = 4;
            // 
            // lblTempsCalculRes
            // 
            this.lblTempsCalculRes.AutoSize = true;
            this.lblTempsCalculRes.Location = new System.Drawing.Point(105, 25);
            this.lblTempsCalculRes.Name = "lblTempsCalculRes";
            this.lblTempsCalculRes.Size = new System.Drawing.Size(0, 13);
            this.lblTempsCalculRes.TabIndex = 3;
            // 
            // lblNoeudsFermes
            // 
            this.lblNoeudsFermes.AutoSize = true;
            this.lblNoeudsFermes.Location = new System.Drawing.Point(16, 71);
            this.lblNoeudsFermes.Name = "lblNoeudsFermes";
            this.lblNoeudsFermes.Size = new System.Drawing.Size(137, 13);
            this.lblNoeudsFermes.TabIndex = 2;
            this.lblNoeudsFermes.Text = "Nombre de noeuds fermés :";
            // 
            // lblNoeudsOuverts
            // 
            this.lblNoeudsOuverts.AutoSize = true;
            this.lblNoeudsOuverts.Location = new System.Drawing.Point(16, 47);
            this.lblNoeudsOuverts.Name = "lblNoeudsOuverts";
            this.lblNoeudsOuverts.Size = new System.Drawing.Size(141, 13);
            this.lblNoeudsOuverts.TabIndex = 1;
            this.lblNoeudsOuverts.Text = "Nombre de noeuds ouverts :";
            // 
            // lblTempsCalcul
            // 
            this.lblTempsCalcul.AutoSize = true;
            this.lblTempsCalcul.Location = new System.Drawing.Point(16, 25);
            this.lblTempsCalcul.Name = "lblTempsCalcul";
            this.lblTempsCalcul.Size = new System.Drawing.Size(91, 13);
            this.lblTempsCalcul.TabIndex = 0;
            this.lblTempsCalcul.Text = "Temps de calcul :";
            // 
            // gbTaquin
            // 
            this.gbTaquin.Controls.Add(this.tbTaquin24);
            this.gbTaquin.Controls.Add(this.tbTaquin23);
            this.gbTaquin.Controls.Add(this.tbTaquin22);
            this.gbTaquin.Controls.Add(this.tbTaquin21);
            this.gbTaquin.Controls.Add(this.tbTaquin20);
            this.gbTaquin.Controls.Add(this.tbTaquin19);
            this.gbTaquin.Controls.Add(this.tbTaquin18);
            this.gbTaquin.Controls.Add(this.tbTaquin17);
            this.gbTaquin.Controls.Add(this.tbTaquin16);
            this.gbTaquin.Controls.Add(this.tbTaquin15);
            this.gbTaquin.Controls.Add(this.tbTaquin14);
            this.gbTaquin.Controls.Add(this.tbTaquin13);
            this.gbTaquin.Controls.Add(this.tbTaquin12);
            this.gbTaquin.Controls.Add(this.tbTaquin11);
            this.gbTaquin.Controls.Add(this.tbTaquin10);
            this.gbTaquin.Controls.Add(this.tbTaquin9);
            this.gbTaquin.Controls.Add(this.tbTaquin7);
            this.gbTaquin.Controls.Add(this.tbTaquin8);
            this.gbTaquin.Controls.Add(this.tbTaquin6);
            this.gbTaquin.Controls.Add(this.tbTaquin5);
            this.gbTaquin.Controls.Add(this.tbTaquin4);
            this.gbTaquin.Controls.Add(this.tbTaquin3);
            this.gbTaquin.Controls.Add(this.tbTaquin2);
            this.gbTaquin.Controls.Add(this.tbTaquin1);
            this.gbTaquin.Controls.Add(this.tbTaquin0);
            this.gbTaquin.Location = new System.Drawing.Point(12, 136);
            this.gbTaquin.Name = "gbTaquin";
            this.gbTaquin.Size = new System.Drawing.Size(257, 266);
            this.gbTaquin.TabIndex = 10;
            this.gbTaquin.TabStop = false;
            this.gbTaquin.Text = "Taquin";
            // 
            // tbTaquin24
            // 
            this.tbTaquin24.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin24.Location = new System.Drawing.Point(199, 210);
            this.tbTaquin24.Name = "tbTaquin24";
            this.tbTaquin24.ReadOnly = true;
            this.tbTaquin24.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin24.TabIndex = 24;
            this.tbTaquin24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin23
            // 
            this.tbTaquin23.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin23.Location = new System.Drawing.Point(155, 210);
            this.tbTaquin23.Name = "tbTaquin23";
            this.tbTaquin23.ReadOnly = true;
            this.tbTaquin23.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin23.TabIndex = 23;
            this.tbTaquin23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin22
            // 
            this.tbTaquin22.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin22.Location = new System.Drawing.Point(111, 210);
            this.tbTaquin22.Name = "tbTaquin22";
            this.tbTaquin22.ReadOnly = true;
            this.tbTaquin22.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin22.TabIndex = 22;
            this.tbTaquin22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin21
            // 
            this.tbTaquin21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin21.Location = new System.Drawing.Point(67, 210);
            this.tbTaquin21.Name = "tbTaquin21";
            this.tbTaquin21.ReadOnly = true;
            this.tbTaquin21.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin21.TabIndex = 21;
            this.tbTaquin21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin20
            // 
            this.tbTaquin20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin20.Location = new System.Drawing.Point(22, 210);
            this.tbTaquin20.Name = "tbTaquin20";
            this.tbTaquin20.ReadOnly = true;
            this.tbTaquin20.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin20.TabIndex = 20;
            this.tbTaquin20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin19
            // 
            this.tbTaquin19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin19.Location = new System.Drawing.Point(198, 166);
            this.tbTaquin19.Name = "tbTaquin19";
            this.tbTaquin19.ReadOnly = true;
            this.tbTaquin19.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin19.TabIndex = 19;
            this.tbTaquin19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin18
            // 
            this.tbTaquin18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin18.Location = new System.Drawing.Point(154, 166);
            this.tbTaquin18.Name = "tbTaquin18";
            this.tbTaquin18.ReadOnly = true;
            this.tbTaquin18.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin18.TabIndex = 18;
            this.tbTaquin18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin17
            // 
            this.tbTaquin17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin17.Location = new System.Drawing.Point(110, 166);
            this.tbTaquin17.Name = "tbTaquin17";
            this.tbTaquin17.ReadOnly = true;
            this.tbTaquin17.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin17.TabIndex = 17;
            this.tbTaquin17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin16
            // 
            this.tbTaquin16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin16.Location = new System.Drawing.Point(66, 166);
            this.tbTaquin16.Name = "tbTaquin16";
            this.tbTaquin16.ReadOnly = true;
            this.tbTaquin16.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin16.TabIndex = 16;
            this.tbTaquin16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin15
            // 
            this.tbTaquin15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin15.Location = new System.Drawing.Point(22, 166);
            this.tbTaquin15.Name = "tbTaquin15";
            this.tbTaquin15.ReadOnly = true;
            this.tbTaquin15.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin15.TabIndex = 15;
            this.tbTaquin15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin14
            // 
            this.tbTaquin14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin14.Location = new System.Drawing.Point(198, 122);
            this.tbTaquin14.Name = "tbTaquin14";
            this.tbTaquin14.ReadOnly = true;
            this.tbTaquin14.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin14.TabIndex = 14;
            this.tbTaquin14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin13
            // 
            this.tbTaquin13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin13.Location = new System.Drawing.Point(154, 122);
            this.tbTaquin13.Name = "tbTaquin13";
            this.tbTaquin13.ReadOnly = true;
            this.tbTaquin13.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin13.TabIndex = 13;
            this.tbTaquin13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin12
            // 
            this.tbTaquin12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin12.Location = new System.Drawing.Point(110, 122);
            this.tbTaquin12.Name = "tbTaquin12";
            this.tbTaquin12.ReadOnly = true;
            this.tbTaquin12.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin12.TabIndex = 12;
            this.tbTaquin12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin11
            // 
            this.tbTaquin11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin11.Location = new System.Drawing.Point(66, 122);
            this.tbTaquin11.Name = "tbTaquin11";
            this.tbTaquin11.ReadOnly = true;
            this.tbTaquin11.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin11.TabIndex = 11;
            this.tbTaquin11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin10
            // 
            this.tbTaquin10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin10.Location = new System.Drawing.Point(22, 122);
            this.tbTaquin10.Name = "tbTaquin10";
            this.tbTaquin10.ReadOnly = true;
            this.tbTaquin10.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin10.TabIndex = 10;
            this.tbTaquin10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin9
            // 
            this.tbTaquin9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin9.Location = new System.Drawing.Point(198, 78);
            this.tbTaquin9.Name = "tbTaquin9";
            this.tbTaquin9.ReadOnly = true;
            this.tbTaquin9.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin9.TabIndex = 9;
            this.tbTaquin9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin7
            // 
            this.tbTaquin7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin7.Location = new System.Drawing.Point(110, 78);
            this.tbTaquin7.Name = "tbTaquin7";
            this.tbTaquin7.ReadOnly = true;
            this.tbTaquin7.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin7.TabIndex = 8;
            this.tbTaquin7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin8
            // 
            this.tbTaquin8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin8.Location = new System.Drawing.Point(154, 78);
            this.tbTaquin8.Name = "tbTaquin8";
            this.tbTaquin8.ReadOnly = true;
            this.tbTaquin8.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin8.TabIndex = 7;
            this.tbTaquin8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin6
            // 
            this.tbTaquin6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin6.Location = new System.Drawing.Point(66, 78);
            this.tbTaquin6.Name = "tbTaquin6";
            this.tbTaquin6.ReadOnly = true;
            this.tbTaquin6.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin6.TabIndex = 6;
            this.tbTaquin6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin5
            // 
            this.tbTaquin5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin5.Location = new System.Drawing.Point(22, 78);
            this.tbTaquin5.Name = "tbTaquin5";
            this.tbTaquin5.ReadOnly = true;
            this.tbTaquin5.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin5.TabIndex = 5;
            this.tbTaquin5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin4
            // 
            this.tbTaquin4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin4.Location = new System.Drawing.Point(198, 34);
            this.tbTaquin4.Name = "tbTaquin4";
            this.tbTaquin4.ReadOnly = true;
            this.tbTaquin4.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin4.TabIndex = 4;
            this.tbTaquin4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin3
            // 
            this.tbTaquin3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin3.Location = new System.Drawing.Point(154, 34);
            this.tbTaquin3.Name = "tbTaquin3";
            this.tbTaquin3.ReadOnly = true;
            this.tbTaquin3.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin3.TabIndex = 3;
            this.tbTaquin3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin2
            // 
            this.tbTaquin2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin2.Location = new System.Drawing.Point(110, 34);
            this.tbTaquin2.Name = "tbTaquin2";
            this.tbTaquin2.ReadOnly = true;
            this.tbTaquin2.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin2.TabIndex = 2;
            this.tbTaquin2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin1
            // 
            this.tbTaquin1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin1.Location = new System.Drawing.Point(67, 34);
            this.tbTaquin1.Name = "tbTaquin1";
            this.tbTaquin1.ReadOnly = true;
            this.tbTaquin1.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin1.TabIndex = 1;
            this.tbTaquin1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTaquin0
            // 
            this.tbTaquin0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tbTaquin0.Location = new System.Drawing.Point(22, 34);
            this.tbTaquin0.Name = "tbTaquin0";
            this.tbTaquin0.ReadOnly = true;
            this.tbTaquin0.Size = new System.Drawing.Size(38, 38);
            this.tbTaquin0.TabIndex = 0;
            this.tbTaquin0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblInitTaquin
            // 
            this.lblInitTaquin.AutoSize = true;
            this.lblInitTaquin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblInitTaquin.Location = new System.Drawing.Point(54, 102);
            this.lblInitTaquin.Name = "lblInitTaquin";
            this.lblInitTaquin.Size = new System.Drawing.Size(162, 20);
            this.lblInitTaquin.TabIndex = 9;
            this.lblInitTaquin.Text = "Initialisation du taquin";
            // 
            // lblTitre
            // 
            this.lblTitre.AutoSize = true;
            this.lblTitre.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblTitre.Location = new System.Drawing.Point(205, 19);
            this.lblTitre.Name = "lblTitre";
            this.lblTitre.Size = new System.Drawing.Size(255, 26);
            this.lblTitre.TabIndex = 8;
            this.lblTitre.Text = "Résolution de taquin 5X5";
            // 
            // gbAction
            // 
            this.gbAction.Controls.Add(this.btnChoixTaquin3);
            this.gbAction.Controls.Add(this.btnChoixTaquin2);
            this.gbAction.Controls.Add(this.btnChoixTaquin1);
            this.gbAction.Controls.Add(this.lblChoixTaquin);
            this.gbAction.Controls.Add(this.btnResoudre);
            this.gbAction.Location = new System.Drawing.Point(448, 406);
            this.gbAction.Name = "gbAction";
            this.gbAction.Size = new System.Drawing.Size(292, 92);
            this.gbAction.TabIndex = 16;
            this.gbAction.TabStop = false;
            this.gbAction.Text = "Actions";
            // 
            // btnChoixTaquin3
            // 
            this.btnChoixTaquin3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnChoixTaquin3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChoixTaquin3.Location = new System.Drawing.Point(96, 43);
            this.btnChoixTaquin3.Name = "btnChoixTaquin3";
            this.btnChoixTaquin3.Size = new System.Drawing.Size(30, 30);
            this.btnChoixTaquin3.TabIndex = 11;
            this.btnChoixTaquin3.Text = "C";
            this.btnChoixTaquin3.UseVisualStyleBackColor = false;
            this.btnChoixTaquin3.Click += new System.EventHandler(this.btnChoixTaquin3_Click);
            // 
            // btnChoixTaquin2
            // 
            this.btnChoixTaquin2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnChoixTaquin2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChoixTaquin2.Location = new System.Drawing.Point(60, 43);
            this.btnChoixTaquin2.Name = "btnChoixTaquin2";
            this.btnChoixTaquin2.Size = new System.Drawing.Size(30, 30);
            this.btnChoixTaquin2.TabIndex = 10;
            this.btnChoixTaquin2.Text = "B";
            this.btnChoixTaquin2.UseVisualStyleBackColor = false;
            this.btnChoixTaquin2.Click += new System.EventHandler(this.btnChoixTaquin2_Click);
            // 
            // btnChoixTaquin1
            // 
            this.btnChoixTaquin1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnChoixTaquin1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChoixTaquin1.Location = new System.Drawing.Point(23, 43);
            this.btnChoixTaquin1.Name = "btnChoixTaquin1";
            this.btnChoixTaquin1.Size = new System.Drawing.Size(30, 30);
            this.btnChoixTaquin1.TabIndex = 9;
            this.btnChoixTaquin1.Text = "A";
            this.btnChoixTaquin1.UseVisualStyleBackColor = false;
            this.btnChoixTaquin1.Click += new System.EventHandler(this.btnChoixTaquin1_Click);
            // 
            // lblChoixTaquin
            // 
            this.lblChoixTaquin.AutoSize = true;
            this.lblChoixTaquin.Location = new System.Drawing.Point(35, 22);
            this.lblChoixTaquin.Name = "lblChoixTaquin";
            this.lblChoixTaquin.Size = new System.Drawing.Size(80, 13);
            this.lblChoixTaquin.TabIndex = 8;
            this.lblChoixTaquin.Text = "Choix du taquin";
            // 
            // btnResoudre
            // 
            this.btnResoudre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnResoudre.Location = new System.Drawing.Point(165, 34);
            this.btnResoudre.Name = "btnResoudre";
            this.btnResoudre.Size = new System.Drawing.Size(98, 39);
            this.btnResoudre.TabIndex = 1;
            this.btnResoudre.Text = "Résoudre";
            this.btnResoudre.UseVisualStyleBackColor = false;
            this.btnResoudre.Click += new System.EventHandler(this.btnResoudre_Click);
            // 
            // FormTaquin5X5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(883, 512);
            this.Controls.Add(this.gbAction);
            this.Controls.Add(this.lblArbreExploration);
            this.Controls.Add(this.lblCoupGagner);
            this.Controls.Add(this.trArbreExploration);
            this.Controls.Add(this.lbCoupGagner);
            this.Controls.Add(this.gbResultats);
            this.Controls.Add(this.gbTaquin);
            this.Controls.Add(this.lblInitTaquin);
            this.Controls.Add(this.lblTitre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "FormTaquin5X5";
            this.Text = "Résolution 5x5 : Projet IA - Fournier Nicol";
            this.gbResultats.ResumeLayout(false);
            this.gbResultats.PerformLayout();
            this.gbTaquin.ResumeLayout(false);
            this.gbTaquin.PerformLayout();
            this.gbAction.ResumeLayout(false);
            this.gbAction.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblArbreExploration;
        private System.Windows.Forms.Label lblCoupGagner;
        private System.Windows.Forms.TreeView trArbreExploration;
        private System.Windows.Forms.ListBox lbCoupGagner;
        private System.Windows.Forms.GroupBox gbResultats;
        private System.Windows.Forms.Label lblNbNoeudsFermesRes;
        private System.Windows.Forms.Label lblNbNoeudsOuvertsRes;
        private System.Windows.Forms.Label lblTempsCalculRes;
        private System.Windows.Forms.Label lblNoeudsFermes;
        private System.Windows.Forms.Label lblNoeudsOuverts;
        private System.Windows.Forms.Label lblTempsCalcul;
        private System.Windows.Forms.GroupBox gbTaquin;
        private System.Windows.Forms.TextBox tbTaquin24;
        private System.Windows.Forms.TextBox tbTaquin23;
        private System.Windows.Forms.TextBox tbTaquin22;
        private System.Windows.Forms.TextBox tbTaquin21;
        private System.Windows.Forms.TextBox tbTaquin20;
        private System.Windows.Forms.TextBox tbTaquin19;
        private System.Windows.Forms.TextBox tbTaquin18;
        private System.Windows.Forms.TextBox tbTaquin17;
        private System.Windows.Forms.TextBox tbTaquin16;
        private System.Windows.Forms.TextBox tbTaquin15;
        private System.Windows.Forms.TextBox tbTaquin14;
        private System.Windows.Forms.TextBox tbTaquin13;
        private System.Windows.Forms.TextBox tbTaquin12;
        private System.Windows.Forms.TextBox tbTaquin11;
        private System.Windows.Forms.TextBox tbTaquin10;
        private System.Windows.Forms.TextBox tbTaquin9;
        private System.Windows.Forms.TextBox tbTaquin7;
        private System.Windows.Forms.TextBox tbTaquin8;
        private System.Windows.Forms.TextBox tbTaquin6;
        private System.Windows.Forms.TextBox tbTaquin5;
        private System.Windows.Forms.TextBox tbTaquin4;
        private System.Windows.Forms.TextBox tbTaquin3;
        private System.Windows.Forms.TextBox tbTaquin2;
        private System.Windows.Forms.TextBox tbTaquin1;
        private System.Windows.Forms.TextBox tbTaquin0;
        private System.Windows.Forms.Label lblInitTaquin;
        private System.Windows.Forms.Label lblTitre;
        private System.Windows.Forms.GroupBox gbAction;
        private System.Windows.Forms.Button btnResoudre;
        private System.Windows.Forms.Button btnChoixTaquin3;
        private System.Windows.Forms.Button btnChoixTaquin2;
        private System.Windows.Forms.Button btnChoixTaquin1;
        private System.Windows.Forms.Label lblChoixTaquin;
    }
}